import { motion, AnimatePresence } from 'motion/react';
import { User, X, LogIn, UserPlus } from 'lucide-react';
import { useGameContext } from '../context/GameContext';
import { useLanguage } from '../context/LanguageContext';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function AuthModal({ isOpen, onClose }: AuthModalProps) {
  const { setAuthMode } = useGameContext();
  const { t } = useLanguage();

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          className="bg-[#1a1a1a] rounded-3xl p-6 md:p-8 max-w-sm w-full border border-white/10 shadow-2xl relative overflow-hidden"
        >
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 bg-white/5 hover:bg-white/10 rounded-full text-gray-400 hover:text-white transition-colors z-10"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="text-center mb-8">
            <div className="relative w-20 h-20 mx-auto mb-4">
              <div className="absolute inset-0 bg-blue-500/20 rounded-full animate-pulse" />
              <div className="relative bg-gradient-to-br from-blue-400 to-purple-500 rounded-full w-full h-full flex items-center justify-center shadow-lg shadow-blue-500/50">
                <User className="w-10 h-10 text-white" />
              </div>
            </div>
            <h2 className="text-2xl font-black text-white mb-2">Welcome to Vault</h2>
            <p className="text-gray-400 text-sm">
              Log in to save your progress, earn achievements, and climb the leaderboards!
            </p>
          </div>

          <div className="space-y-3">
            <button
              onClick={() => {
                setAuthMode('logged_in');
                onClose();
              }}
              className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold transition-all flex items-center justify-center gap-2 shadow-lg shadow-blue-600/20"
            >
              <LogIn className="w-5 h-5" />
              Log In
            </button>
            <button
              onClick={() => {
                setAuthMode('logged_in');
                onClose();
              }}
              className="w-full py-3 bg-white/10 hover:bg-white/20 text-white rounded-xl font-bold transition-colors flex items-center justify-center gap-2"
            >
              <UserPlus className="w-5 h-5" />
              Sign Up
            </button>
          </div>

          <div className="mt-6 text-center">
            <button
              onClick={() => {
                setAuthMode('guest');
                onClose();
              }}
              className="text-gray-500 hover:text-gray-300 text-sm font-medium transition-colors"
            >
              Enter Guest Mode
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
