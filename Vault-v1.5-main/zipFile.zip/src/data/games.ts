export interface Game {
  id: string;
  title: string;
  category: string;
  thumbnail: string;
  embedUrl: string;
}

export const games: Game[] = [
  // Action (Replaced broken ones with reliable alternatives)
  { id: 'snake', title: 'Neon Snake', category: 'Action', thumbnail: '', embedUrl: 'native:SnakeGame' },
  { id: 'dashcraft', title: 'Dashcraft.io', category: 'Action', thumbnail: '', embedUrl: 'https://dashcraft.io/' },
  { id: 'venge-io', title: 'Venge.io', category: 'Action', thumbnail: '', embedUrl: 'https://venge.io/' },
  { id: 'ev-io', title: 'Ev.io', category: 'Action', thumbnail: '', embedUrl: 'https://ev.io/' },
  { id: 'geometry-dash', title: 'Geometry Dash', category: 'Action', thumbnail: '', embedUrl: 'https://geometrydash-free.github.io/' },

  // Clicker (Native)
  { id: 'neon-clicker', title: 'Sigma Clicker', category: 'Clicker', thumbnail: '', embedUrl: 'native:NeonClicker' },

  // Puzzle (Native & Working Iframes)
  { id: 'block-blast', title: 'Block Blast', category: 'Puzzle', thumbnail: '', embedUrl: 'https://blockblastonline.com/' },
  { id: 'hextris', title: 'Hextris', category: 'Puzzle', thumbnail: '', embedUrl: 'https://hextris.io/' },
  { id: 'tetris', title: 'Tetris', category: 'Puzzle', thumbnail: '', embedUrl: 'https://chvin.github.io/react-tetris/?lan=en' },
  { id: 'sudoku', title: 'Sudoku', category: 'Puzzle', thumbnail: '', embedUrl: 'https://sudoku.com/' },
  { id: '2048', title: '2048', category: 'Puzzle', thumbnail: '', embedUrl: 'native:Game2048' },
  { id: 'little-alchemy-2', title: 'Little Alchemy 2', category: 'Puzzle', thumbnail: '', embedUrl: 'https://littlealchemy2.com/' },

  // Sports
  { id: 'basket-random', title: 'Basket Random', category: 'Sports', thumbnail: '', embedUrl: 'https://basket-random.github.io/' },
  { id: 'rocketgoal', title: 'Rocketgoal.io', category: 'Sports', thumbnail: '', embedUrl: 'https://rocketgoal.io/' },
  { id: 'soccer-random', title: 'Soccer Random', category: 'Sports', thumbnail: '', embedUrl: 'https://github.io/soccer-random' }, // Placeholder, will fix if needed

  // IO Games
  { id: 'paper-io-2', title: 'Paper.io 2', category: 'IO Games', thumbnail: '', embedUrl: 'https://paper-io.com/' },
  { id: 'territorial-io', title: 'Territorial.io', category: 'IO Games', thumbnail: '', embedUrl: 'https://territorial.io/' },

  // Classics (Native & Working Iframes)
  { id: 'chess', title: 'Chess (2 Player)', category: 'Classics', thumbnail: '', embedUrl: 'native:ChessGame' },
  { id: 'tic-tac-toe', title: 'Tic Tac Toe (2 Player)', category: 'Classics', thumbnail: '', embedUrl: 'native:TicTacToe' },
  { id: 'solitaire', title: 'Solitaire', category: 'Classics', thumbnail: '', embedUrl: 'https://www.google.com/logos/fnbx/solitaire/standalone.html' },
  { id: 'bitlife', title: 'BitLife', category: 'Classics', thumbnail: '', embedUrl: 'https://bitlifeonline.github.io/' },
];
